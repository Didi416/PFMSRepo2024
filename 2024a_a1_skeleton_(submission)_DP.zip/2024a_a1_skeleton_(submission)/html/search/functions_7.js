var searchData=
[
  ['timeinmotion_56',['timeInMotion',['../classController.html#af1472481d84dca376962d905e4107432',1,'Controller::timeInMotion()'],['../classControllerInterface.html#a317aec52ae6671edad34f44490845403',1,'ControllerInterface::timeInMotion()']]],
  ['timetogoal_57',['timeToGoal',['../classController.html#a8164045766f1c1b455c930bebdf6a64d',1,'Controller::timeToGoal()'],['../classControllerInterface.html#a4d2367da8a1590852c5f30ef76f657ab',1,'ControllerInterface::timeToGoal()']]]
];
