var searchData=
[
  ['distancetogoal_40',['distanceToGoal',['../classController.html#aa53232d0d11f135dbbfeae9bee3f51fb',1,'Controller::distanceToGoal()'],['../classControllerInterface.html#a0851bb04a24f80909092257f7bf65948',1,'ControllerInterface::distanceToGoal()']]],
  ['distancetravelled_41',['distanceTravelled',['../classController.html#a03d089fb18dfa08076e652f567d557f4',1,'Controller::distanceTravelled()'],['../classControllerInterface.html#aa96aaeb9881d6458991b55f477365f70',1,'ControllerInterface::distanceTravelled()']]],
  ['drive_42',['drive',['../classSkidSteer.html#ac9e32c2f90b0b29858e12ba8e2e91c30',1,'SkidSteer']]]
];
