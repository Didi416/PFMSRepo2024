var indexSectionsWithContent =
{
  0: "abcdgmoprst",
  1: "acms",
  2: "m",
  3: "acdgmrst",
  4: "o",
  5: "dt",
  6: "bp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "enums",
  5: "enumvalues",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Enumerations",
  5: "Enumerator",
  6: "Pages"
};

