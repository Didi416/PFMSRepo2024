var searchData=
[
  ['getdistancetravelled_43',['getDistanceTravelled',['../classMission.html#afd8c9afab2a836714d9dd8566e8735be',1,'Mission::getDistanceTravelled()'],['../classMissionInterface.html#a4d8440b8f1aef3c142e933d4b3c50555',1,'MissionInterface::getDistanceTravelled()']]],
  ['getodometry_44',['getOdometry',['../classController.html#a016f8775066ddce752f4f4c267cbe5df',1,'Controller::getOdometry()'],['../classControllerInterface.html#a5933b45e1db184b755eb5e0f787d9738',1,'ControllerInterface::getOdometry()']]],
  ['getplatformgoalassociation_45',['getPlatformGoalAssociation',['../classMission.html#a51163e354f31c1f252689ec66147a56a',1,'Mission::getPlatformGoalAssociation()'],['../classMissionInterface.html#a0398d41e202efe40711688906a153824',1,'MissionInterface::getPlatformGoalAssociation()']]],
  ['getplatformtype_46',['getPlatformType',['../classController.html#abbe3aafaa87927750fbb0e6576d7ae7d',1,'Controller::getPlatformType()'],['../classControllerInterface.html#af3d4b81e14aa6821d9e5db8c78c791fc',1,'ControllerInterface::getPlatformType()']]],
  ['gettimemoving_47',['getTimeMoving',['../classMission.html#aec42365ce1566a72796193581358f7a8',1,'Mission::getTimeMoving()'],['../classMissionInterface.html#a5bbd0f7f2988ec9d516f09ac801c75cd',1,'MissionInterface::getTimeMoving()']]]
];
